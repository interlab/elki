[center][size=16pt][b]Fancybox 4 ElkArte Version 1.0.2[/b][/size][/center]
[hr]

[color=blue][b][size=12pt][u]License[/u][/size][/b][/color]
This ElkArte addon is released under a MPL V1.1 license, a copy of it with its provisions is included with the package.

[color=blue][b][size=12pt][u]Introduction[/u][/size][/b][/color]
This adds a lightbox / zoom effect to thumbnail images and attachments.  It will work on attachments and in-line images.
[hr]
Fancybox JS is licensed under a Creative Commons Attribution-Non Commercial 3.0 License. You are free to use fancyBox for your personal or non-profit website projects. You must get the author's permission to use fancyBox for commercial websites by paying a fee.  [url=http://fancyapps.com/fancybox/#license]fancybox[/url]

[color=blue][b][size=12pt][u]Features[/u][/size][/b][/color]
o Expands a thumbnail (attachment or in-line image) in to a full-size image in a picture frame when clicked
o Auto size images to fit browser window, with option to expand to full size
o Slideshow for images on page, grouping by individual messages in the topic
o Prev / Next navigation with arrow keys